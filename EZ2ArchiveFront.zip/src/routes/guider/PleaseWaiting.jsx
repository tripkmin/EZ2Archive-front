/*eslint-disable*/

const PleaseWaiting = () => {
  return (
    <div className="pleaseSelectBox">
      <img src={process.env.PUBLIC_URL + '/source/preparing.png'} alt="PleaseSelect"></img>
      <h3>준비 중입니다!</h3>
      <h5>후딱 준비하겠습니다</h5>
    </div>
  )
}


export default PleaseWaiting
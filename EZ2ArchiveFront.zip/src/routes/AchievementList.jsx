/*eslint-disable*/

const AchievementList = () => {

  return (
    <div className="rank-order-selector-wrapper">
      <div className="rank-order-selector">
        테스트
    </div>
   </div>
  )
}

export default AchievementList
/*eslint-disable*/

import axios from "axios"
import { useEffect, useState } from "react"
import { API_URL } from "../services/temp";

const AchievementSelector = () => {

  const [totalSongs, setTotalSongs] = useState()
  const data1 = 25
  const data2 = 20
  const data3 = 36
  const data4 = 34
  const data5 = 38
  const data6 = 40 
  const barLength = 300
  const array = [{ contents : data1, name: "AVERAGE RATE"}, { contents : data2, name: "ALL COOL" }, { contents : data3, name: "NO MISS" }, { contents : data4, name: "S+++"}, { contents : data5, name: "S++"}, { contents : data6, name: "S+"}] 
  useEffect(()=>{
    // 로그인 확인
  }, [])

  const test = () => {
    axios
      // .get(`${API_URL}/rank/list/${key}/${selectedDifficulty}`)
      .get(`${API_URL}/rank/list/FIVE/18`)
      .then((res) => {
        setTotalSongs(res.data.data.length)
        })
      .catch((err) => { console.log(err) })
  }

  test()

  return (
    <div className="achievement-selector-wrapper">
      <div className="achievement-selector">
        <div className="achievement-userinfo">
          <div className="achievement-key-level">
            <h1 className="theme-pp">5K</h1>
            <h4>18</h4>
          </div>
          <h4>USER NAME</h4>
        </div>
        <div className="achievement-detail">
          <h3 className="theme-pp">OVERALL</h3>
            <table>
              <tbody>
                {
                  array.map((el, i) => {
                    return (
                      <tr key={i}>
                        <td>{ (el.contents / totalSongs) * 100}%</td>
                        <td>{ (el.contents / totalSongs) }</td>
                        {/* <td>{ el.name }</td> */}
                        <td>
                          <div className="behind-bar theme-pp-shadow">
                            <div className="bar" style={{width: `${barLength * (el.contents / totalSongs)}px`}}></div>
                            <span>{el.name}</span>
                            {/* <span>{ (el.contents / totalSongs) * 100}%</span> */}
                          </div>
                        </td>
                      </tr>
                    )
                  })
                } 
              </tbody>
            </table>
        </div>
        {/* <div className="achievement-filter">
          <h3 className="theme-pp">FILTER</h3>
          <div className="achievement-filter-key-title">
            <h4 className="theme-pp">KEY</h4>
          </div>
          <div className="achievement-filter-key">
            <span>4K</span>
            <span>5K</span>
            <span>6K</span>
            <span>8K</span>
          </div>
          <div className="achievement-filter-level-title">
            <h4 className="theme-pp">LEVEL</h4>
          </div>
          <div className="achievement-filter-level">
            <span>1~10</span>
            <span>11</span>
            <span>12</span>
            <span>13</span>
            <span>14</span>
            <span>15</span>
          </div>
          <div className="achievement-filter-level">
            <span>16</span>
            <span>17</span>
            <span>18</span>
            <span>19</span>
            <span>20</span>
          </div>
        </div> */}
    </div>
   </div>
  )
}

export default AchievementSelector